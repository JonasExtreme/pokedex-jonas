import './App.css'
import Pokedex from './components/Pokedex'

function App() {

  return (
    <>
    <div className="corpo">
      <Pokedex />
    </div>
    </>
  )
}

export default App
